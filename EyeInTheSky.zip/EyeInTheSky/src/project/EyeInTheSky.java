package project;
public class EyeInTheSky {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Game game =  new Game("EYE IN THE SKY..!",400,400);
       game.start();
       
       
       
    }
    
}
